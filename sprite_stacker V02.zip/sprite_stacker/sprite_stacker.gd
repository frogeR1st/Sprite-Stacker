@tool
extends EditorPlugin


func _enable_plugin() -> void:
	# Add autoloads here.
	pass


func _disable_plugin() -> void:
	# Remove autoloads here.
	pass


func _enter_tree() -> void:
	# Initialization of the plugin goes here.
	add_custom_type("Basic Sprite Stacker", "Node2D", preload("res://addons/sprite_stacker/Basic Sprite Stacker/Basic Sprite Stacker.gd"), preload("res://addons/sprite_stacker/Basic Sprite Stacker/Stack.svg"))



func _exit_tree() -> void:
	# Clean-up of the plugin goes here.
	remove_custom_type("Basic Sprite Stacker")
