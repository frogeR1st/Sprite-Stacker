extends Resource

class_name SpriteStack

@export_category("Sprite Stack")
@export var Sprites: Array[Texture2D] = []
