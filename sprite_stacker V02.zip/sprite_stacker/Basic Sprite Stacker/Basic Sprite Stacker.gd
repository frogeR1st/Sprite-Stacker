@tool
extends Node2D

@export_category("In Game")
@export var UpdateIngame: bool = false

@export_category("Transform")
@export var StackOffset: Vector2 = Vector2.ZERO
@export_custom(PROPERTY_HINT_NONE, "suffix:°") var StackRotation: float = 0

@export_category("Stack")
@export var StackDistance: float = 1
@export var DuplicateLayers: int = 1

@export_category("Visual")
@export var Stack: SpriteStack
@export var Filter: CanvasItem.TextureFilter = CanvasItem.TextureFilter.TEXTURE_FILTER_NEAREST
#For Rendering Server use RenderingServer.CanvasItemTextureFilter
#For Sprites use CanvasItem.TextureFilter

var StackSize: int = 0

var CanvasItems: Array = []

func Draw(SpriteTexture : Texture2D, Position: Vector2 = Vector2.ZERO, Rotation: float = 0, ZIndex: int = 0):
	var ItemTransform : Transform2D = Transform2D(deg_to_rad(Rotation), Position)
	
	var Item = RenderingServer.canvas_item_create() # Creates Canvas Item
	CanvasItems.append(Item) # Adds Canvas Item To ArrayCustomFormat
	
	RenderingServer.canvas_item_set_parent(Item, get_canvas_item()) # Sets the canvas item to be a child of the canvas item thingy
	
	if SpriteTexture is AtlasTexture:
		RenderingServer.canvas_item_add_texture_rect_region(Item, Rect2(-SpriteTexture.get_size() * 0.5, SpriteTexture.get_size()), SpriteTexture, SpriteTexture.region)
	else:
		RenderingServer.canvas_item_add_texture_rect(Item, Rect2(-SpriteTexture.get_size() * 0.5, SpriteTexture.get_size()), SpriteTexture) # Adds Texture to canvas item
	
	#RenderingServer.canvas_item_set_default_texture_filter(Item, Filter)
	
	RenderingServer.canvas_item_set_z_as_relative_to_parent(Item, true)
	RenderingServer.canvas_item_set_z_index(Item, ZIndex + z_index)
	
	RenderingServer.canvas_item_set_transform(Item, ItemTransform)

func UpdateStackViaRenderingServer(): #should be much better for prefeormance, but isnt...
	StackSize = 0

	for item in CanvasItems:
		pass
		#RenderingServer.canvas_item_clear(item)
		#RenderingServer.

	for layer in Stack.Sprites:
		for duplicate in DuplicateLayers:
			var Position: Vector2 = StackOffset
			Position.y += -StackDistance * StackSize
			Draw(layer, Position, StackRotation, StackSize)
			
			StackSize += 1

func UpdateStackViaSprite2D():# Quick & dirty solution
	for child in get_children():
		child.queue_free()
		
	StackSize = 0
	
	for layer in Stack.Sprites:
		for duplicate in DuplicateLayers:
			
			var Sprite: Sprite2D = Sprite2D.new()
			
			#Visual
			Sprite.texture_filter = Filter
			
			#Transform
			Sprite.texture = layer
			Sprite.position.y = StackSize * -StackDistance
			Sprite.position += StackOffset
			Sprite.rotation_degrees = StackRotation
			
			add_child(Sprite)
			StackSize += 1
			
func _process(_delta: float) -> void:
	if not Engine.is_editor_hint() and not UpdateIngame:
		return
	
	UpdateStackViaSprite2D()
			
func _ready() -> void:
	for child in get_children():
		child.queue_free()
	
	UpdateStackViaSprite2D()
